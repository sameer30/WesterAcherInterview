import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadFilesService {

  constructor(public httpClient: HttpClient) { }

  public submitFiles(data: any): Observable<any> {
    const url = "http://localhost:4200/file-upload";
    let headers = new HttpHeaders;
    return this.httpClient.post(url, data,{ headers: headers }).pipe(
      map((response: any) => {
        return <any>response;
      })
    )
  }

}
