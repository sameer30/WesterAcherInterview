import { Component } from '@angular/core';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { UploadFilesService } from '../upload-files.service'

@Component({
  selector: 'app-file-upload',
  standalone: true,
  imports: [MatSlideToggleModule],
  templateUrl: './file-upload.component.html',
  styleUrl: './file-upload.component.css'
})
export class FileUploadComponent {
  public fileName: string = "";
  public editChecked: boolean = false;
  public disableBtn: boolean = false;
  public file: any;
  constructor(private uploadService: UploadFilesService){}

  ngOnInit(): void {
    this.editChecked = false;
    this.disableBtn = true;
  }
  public onFileSelected(event: any) {
    console.log(event.target.files[0])
    this.file = event.target.files[0];
    this.fileName = this.file.name;
    this.disableBtn = false;
  }
  public uploadFile(event: any) {
    this.editChecked = false;
    if(this.file && event.checked) {
      console.log(this.editChecked)
      
      this.uploadService.submitFiles(this.file).subscribe((response) => {
        if(response) {
          console.log("File Uploaded Successfully")
        } else {
          console.log("File Upload Failed")
        }
      })
    }
  }
}
